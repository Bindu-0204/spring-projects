package com.cg.flight.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
@SequenceGenerator(name="seq",initialValue = 1,allocationSize = 100) 
public class Airport {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "seq") 
	private int airportId;
	
	@Column(name="AirportName")
	private String airportName;
	
    @Column(name="Abbreviation")
	private String abbreviation;
	
    @Column(name="Location") 
	private String location;
	
	
	@OneToMany(mappedBy="airport")
	private List<Flight> flight;


	public String getAirportName() {
		return airportName;
	}


	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}


	public String getAbbreviation() {
		return abbreviation;
	}


	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public List<Flight> getFlight() {
		return flight;
	}


	public void setFlight(List<Flight> flight) {
		this.flight = flight;
	}

	public int getAirportId() {
		return airportId;
	}


	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}


	public Airport() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Airport(int airportId, String airportName, String abbreviation, String location,
			List<Flight> flight) {
		super();
		this.airportId = airportId;
		this.airportName = airportName;
		this.abbreviation = abbreviation;
		this.location = location;
		this.flight = flight;
	}
	
}
	