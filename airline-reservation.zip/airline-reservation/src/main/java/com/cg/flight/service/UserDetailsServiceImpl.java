package com.cg.flight.service;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.User;
import com.cg.flight.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	public User addUser(User user) throws FlightManagementException{
		return userRepository.save(user);
	}
	public User getUser(int userId) throws FlightManagementException{
		return userRepository.getOne(userId);
		
	}
	public List<User> getAllUser() throws FlightManagementException{
		return userRepository.findAll(); 
	}
	public void updateUser(User user, int userId) throws FlightManagementException{
		user.setUserId(userId);
		userRepository.save(user);
	}
	
	public void deleteUser(int userId) throws FlightManagementException{
		
		userRepository.deleteById(userId);
	}
	
	
	
	
}
