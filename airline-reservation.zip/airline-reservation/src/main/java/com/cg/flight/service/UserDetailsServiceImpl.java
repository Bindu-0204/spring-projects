package com.cg.flight.service;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.model.User;
import com.cg.flight.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	public User addUser(User user) {
		return userRepository.save(user);
	}
	public User getUserById(int userId) {
		return userRepository.getOne(userId);
		
	}
	public List<User> getAllUser(){
		return userRepository.findAll(); 
	}
	public void updateUser(User user, int userId) {
		userRepository.save(user);
	}
	
	
	
	
}
