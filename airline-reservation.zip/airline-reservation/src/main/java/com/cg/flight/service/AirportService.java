package com.cg.flight.service;

import com.cg.flight.model.Airport;


public interface AirportService {

	public Airport addAirport(Airport airport);

	public Airport findById(int airportId);
	
}
