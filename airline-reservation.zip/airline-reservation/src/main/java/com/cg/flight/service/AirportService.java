package com.cg.flight.service;

import java.util.List;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Airport;


public interface AirportService {

	public Airport addAirport(Airport airport) throws FlightManagementException;
	public Airport getAirport(int airportId) throws FlightManagementException;
	List<Airport> getAllAirport() throws FlightManagementException;
	public Airport updateAirport(Airport airport,int airportId) throws FlightManagementException;
	public void deleteAirport(int airportId) throws FlightManagementException;
	
}
