package com.cg.flight.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Email;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
@SequenceGenerator(name = "seq", initialValue = 1, allocationSize = 100)
public class Booking {
	
	@Column(name="BookingId")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int bookingId;
	
	@Email
	@Column(name="CustEmail")
	private String custEmail;
	
	@Column(name="No_of_passengers")
	private int noOfPassengers;
	
	@Column(name="ClassType")
	private String classType;
	
	@Column(name="TotalFare")
	private double totalFare;
	
	@Column(name="SeatNo")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int seatNo;
	
	@Column(name="BookingDate")
	private Date bookingDate;
	
	
	@Column(name="CreditCardInfo")
	private long creditCardInfo;
	
	@Column(name="SrcCity")
	private String srcCity;
	
	@Column(name="DestCity")
	private String destCity;
	

	
	@ManyToOne
	@JoinColumn(name = "userId",insertable = false,updatable = false)
	private User user;
	
	
	
	@ManyToOne()
	@JoinColumn(name = "flightNo",insertable = false,updatable = false)
	private Flight flight;
	
	
	
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public long getCreditCardInfo() {
		return creditCardInfo;
	}
	public void setCreditCardInfo(long creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}
	public String getSrcCity() {
		return srcCity;
	}
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(int bookingId, @Email String custEmail, int noOfPassengers, String classType, double totalFare,
			int seatNo, long creditCardInfo, String srcCity, String destCity) {
		super();
		this.bookingId = bookingId;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNo = seatNo;
		this.creditCardInfo = creditCardInfo;
		this.srcCity = srcCity;
		this.destCity = destCity;
	}
	
	
	}
	
	
	
	
	