package com.cg.flight.service;

import java.util.List;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Flight;

public interface FlightService {
	
	
	Flight getFlight(int flightNo) throws FlightManagementException;
	
	Flight setFlight(Flight flight) throws FlightManagementException;
	List<Flight> getAllFlight() throws FlightManagementException;

	void updateFlight(Flight flight, int flightNo) throws FlightManagementException;
	public void deleteFlight(int flightNo) throws FlightManagementException;
	

}


