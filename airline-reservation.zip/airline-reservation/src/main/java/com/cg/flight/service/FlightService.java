package com.cg.flight.service;

import java.util.List;

import com.cg.flight.model.Flight;

public interface FlightService {
	
	
	Flight getFlight(int flightNo);
	
	Flight setFlight(Flight flight);
	List<Flight> getAllFlight();

	void updateFlight(Flight flight, int flightNo);
	

}


