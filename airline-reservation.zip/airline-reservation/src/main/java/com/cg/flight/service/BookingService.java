package com.cg.flight.service;

import java.util.List;


import com.cg.flight.model.Booking;


public interface BookingService {

	public Booking addBooking(Booking booking);
	public Booking getBookingById(int bookingId);
	public List<Booking> getBooking();
	public Booking updateBooking(Booking booking, int bookingId);
	
}
