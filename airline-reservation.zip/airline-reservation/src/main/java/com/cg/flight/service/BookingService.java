package com.cg.flight.service;

import java.util.List;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Booking;


public interface BookingService {

	public Booking addBooking(Booking booking) throws FlightManagementException;
	public Booking getBookingById(int bookingId) throws FlightManagementException;
	public List<Booking> getAllBooking() throws FlightManagementException;
	public Booking updateBooking(Booking booking, int bookingId) throws FlightManagementException;
	public void deleteBooking(int bookingId) throws FlightManagementException;
	
	
}
