package com.cg.flight.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.model.Airport;
import com.cg.flight.repository.AirportRepository;

@Service
public class AirportServiceImpl implements AirportService {
	
	@Autowired
	private AirportRepository airportRepository;

	
	public Airport addAirport(Airport airport) {

		return airportRepository.save(airport);
	}

	public Airport findById(int airportId)  {

		return airportRepository.getOne(airportId);
	}
	
	
	}

	

	
	




