package com.cg.flight.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Airport;
import com.cg.flight.repository.AirportRepository;

@Service
public class AirportServiceImpl implements AirportService {
	
	@Autowired
	private AirportRepository airportRepository;

	
	public Airport addAirport(Airport airport) throws FlightManagementException{

		return airportRepository.save(airport);
	}


	public Airport getAirport(int airportId) throws FlightManagementException {
		return airportRepository.getOne(airportId);
	}

	public List<Airport> getAllAirport() throws FlightManagementException{
		return airportRepository.findAll();
	}

	
	public Airport updateAirport(Airport airport, int airportId) throws FlightManagementException{
		airport.setAirportId(airportId);
		return airportRepository.save(airport);
	}

	
	public void deleteAirport(int airportId) throws FlightManagementException{
		 airportRepository.deleteById(airportId);
	}
	
	
	}

	

	
	




