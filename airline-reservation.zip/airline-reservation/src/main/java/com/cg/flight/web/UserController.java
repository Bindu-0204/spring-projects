package com.cg.flight.web;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.flight.model.Airport;
import com.cg.flight.model.Booking;
import com.cg.flight.model.Flight;
import com.cg.flight.model.User;
import com.cg.flight.repository.BookingRepository;
import com.cg.flight.service.AirportService;
import com.cg.flight.service.BookingService;
import com.cg.flight.service.FlightService;
import com.cg.flight.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private FlightService flightService;

	@Autowired
	private AirportService airportService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BookingService bookingService;

	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value="/flight", method=RequestMethod.POST)
	public Flight setFlight(@RequestBody Flight flight) {

		log.info(flight.toString());
		
		return flightService.setFlight(flight);

	}
	@RequestMapping(value="/flight/{flightNo}", method=RequestMethod.GET)
	public Flight getFlight(@PathVariable int flightNo)  {
 
		Flight flight = flightService.getFlight(flightNo);
		
		return flight;

	}

	@RequestMapping(value="/flight", method=RequestMethod.GET)
	public  List<Flight> getAllFlight() {
		return flightService.getAllFlight();
	
	}

	@RequestMapping(value="/flight/{flightNo}", method=RequestMethod.PUT)
	public void updateFlight(@RequestBody Flight flight, @PathVariable int flightNo) {

		 flightService.updateFlight(flight,flightNo);
	}

	@RequestMapping(value="/airport", method=RequestMethod.POST)
	public Airport addAirport(@RequestBody Airport airport) {
		 return airportService.addAirport(airport);
	}

	@RequestMapping(value="/airport/{airportId}", method=RequestMethod.GET)
	public Airport findById(@PathVariable int airportId) {	 
			Airport airport = airportService.findById(airportId);
			
			return airport;
	}
	
	@RequestMapping(value="/user", method=RequestMethod.POST)
	public User addUser(@RequestBody User user) {
		return userService.addUser(user);
			
	}
	
	@RequestMapping(value="/user/{userId}", method=RequestMethod.GET)
	public User getUserById(@PathVariable int userId) {
		return userService.getUserById(userId);
		
	}
	
	@RequestMapping(value="/user/{userId}", method=RequestMethod.PUT)
	public void updateUser(@RequestBody User user,@PathVariable int userId) {
		userService.updateUser(user, userId);
		
	}
	@RequestMapping(value="/user", method=RequestMethod.GET)
	public  List<User> getAllUser() {
		return userService.getAllUser();
	
	}
	
	
	
	@RequestMapping(value="/book", method=RequestMethod.POST)
	public Booking addBooking(@RequestBody Booking booking) {
		return bookingService.addBooking(booking);
		
	}
	
	
	
	
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
