package com.cg.flight.web;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Airport;
import com.cg.flight.model.Booking;
import com.cg.flight.model.Flight;
import com.cg.flight.model.User;
import com.cg.flight.service.AirportService;
import com.cg.flight.service.BookingService;
import com.cg.flight.service.FlightService;
import com.cg.flight.service.UserService;


@RestController
public class UserController {
	
	@Autowired
	private FlightService flightService;

	@Autowired
	private AirportService airportService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BookingService bookingService;

	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value="/flight", method=RequestMethod.POST)
	public Flight setFlight(@RequestBody Flight flight) throws FlightManagementException{

		log.info(flight.toString());
		
		return flightService.setFlight(flight);

	}
	@RequestMapping(value="/flight/{flightNo}", method=RequestMethod.GET)
	public Flight getFlight(@PathVariable int flightNo) throws FlightManagementException {
 
		Flight flight = flightService.getFlight(flightNo);
		
		if(flight==null)
		 throw new FlightManagementException(204,"Flight Not Found");
		return flight;
		

	}

	@RequestMapping(value="/flight", method=RequestMethod.GET)
	public  List<Flight> getAllFlight() throws FlightManagementException{
		
		return flightService.getAllFlight();
	
	}

	@RequestMapping(value="/flight/{flightNo}", method=RequestMethod.PUT)
	public void updateFlight(@RequestBody Flight flight, @PathVariable int flightNo) throws FlightManagementException{

		 flightService.updateFlight(flight,flightNo);
	}
	
	@RequestMapping(value="/flight/{flightNo}", method=RequestMethod.DELETE)
	public void deleteFlight(@PathVariable int flightNo) throws FlightManagementException {

		 flightService.deleteFlight(flightNo);
	}
	

	@RequestMapping(value="/airport", method=RequestMethod.POST)
	public Airport addAirport(@RequestBody Airport airport) throws FlightManagementException {
		
		log.info(airport.toString());
		
		 return airportService.addAirport(airport);
	}

	@RequestMapping(value="/airport/{airportId}", method=RequestMethod.GET)
	public Airport getAirport(@PathVariable int airportId) throws FlightManagementException{	 
			Airport airport = airportService.getAirport(airportId);
			
			return airport;
	}
	
	
	@RequestMapping(value="/airport", method=RequestMethod.GET)
	public  List<Airport> getAllAirport() throws FlightManagementException{
		return airportService.getAllAirport();
	
	}
	
	@RequestMapping(value="/airport/{airportId}", method=RequestMethod.PUT)
	public void updateAirport(@RequestBody Airport airport, @PathVariable int airportId) {
		
		airportService.updateAirport(airport,airportId);
	}
	
	@RequestMapping(value="/airport/{airportId}", method=RequestMethod.DELETE)
	public void deleteAirport( @PathVariable int airportId) throws FlightManagementException{

		airportService.deleteAirport(airportId);
	}
	
	
	
	@RequestMapping(value="/user", method=RequestMethod.POST)
	public User addUser(@RequestBody User user) throws FlightManagementException{
		
		log.info(user.toString());
		return userService.addUser(user);
			
	}
	
	@RequestMapping(value="/user/{userId}", method=RequestMethod.GET)
	public User getUser(@PathVariable int userId) throws FlightManagementException{
		
		return userService.getUser(userId);
		
	}
	
	@RequestMapping(value="/user", method=RequestMethod.GET)
	public  List<User> getAllUser() throws FlightManagementException{
		return userService.getAllUser();
	
	}

	@RequestMapping(value="/user/{userId}", method=RequestMethod.PUT)
	public void updateUser(@RequestBody User user,@PathVariable int userId) throws FlightManagementException{

		userService.updateUser(user, userId);
		
	}

	@RequestMapping(value="/user/{userId}", method=RequestMethod.DELETE)
	public void deleteUser(@PathVariable int userId) throws FlightManagementException{
		 userService.deleteUser(userId);
		
	}
	
	@RequestMapping(value="/booking", method=RequestMethod.POST)
	public Booking addBooking(@RequestBody Booking booking) throws FlightManagementException{
		log.info(booking.toString());
		return bookingService.addBooking(booking);
		
	}
	
	@RequestMapping(value="/booking/{bookingId}", method=RequestMethod.GET)
	public Booking getBookingById(@PathVariable int bookingId) throws FlightManagementException{
		return bookingService.getBookingById(bookingId);
		
	}
	
	@RequestMapping(value="/booking", method=RequestMethod.GET)
	public  List<Booking> getAllBooking() throws FlightManagementException{
		return bookingService.getAllBooking();
	
	}

	@RequestMapping(value="/booking/{bookingId}", method=RequestMethod.PUT)
	public void updateBooking(@RequestBody Booking booking,@PathVariable int bookingId) throws FlightManagementException{
		log.info(booking.toString());
		bookingService.updateBooking(booking, bookingId);
		
	}

	@RequestMapping(value="/booking/{bookingId}", method=RequestMethod.DELETE)
	public void deleteBooking(@PathVariable int bookingId) throws FlightManagementException{
		bookingService.deleteBooking(bookingId);
		
	}
	
		
}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
