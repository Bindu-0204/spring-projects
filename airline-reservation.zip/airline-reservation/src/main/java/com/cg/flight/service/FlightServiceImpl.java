package com.cg.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.flight.model.Flight;
import com.cg.flight.repository.FlightRepository;




@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepository;

	
	public Flight getFlight(int flightNo) {

		return flightRepository.getOne(flightNo);
	}

	
	public Flight setFlight(Flight flight) {
		
		return flightRepository.save(flight);
	}
	
	
	public List<Flight> getAllFlight() {
		return flightRepository.findAll();
	}



	public void updateFlight(Flight flight, int flightNo) {
		
		flight.setFlightNo(flightNo);
		
		
		 flightRepository.save(flight);
	}
	
}


