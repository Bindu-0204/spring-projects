package com.cg.flight.exception;

public class FlightManagementException extends RuntimeException{
private static final long serialVersionUID = 1L;
	
	private int code;
	private String message;
		
	public FlightManagementException(int code, String msg) {
		super();
		this.code = code;
		this.message = msg;
		
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "FlightManagementException [code=" + code + ", msg=" + message + "]";
	}

}
