package com.cg.flight.service;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.Booking;
import com.cg.flight.repository.BookingRepository;




@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	BookingRepository bookingRepository;

public Booking addBooking(Booking booking) throws FlightManagementException {
		
		return bookingRepository.save(booking);
	}

	
	public Booking getBookingById(int bookingId) throws FlightManagementException {
		
		
		return bookingRepository.getOne(bookingId); 
	}

	
	public List<Booking> getAllBooking() throws FlightManagementException{
		
		return bookingRepository.findAll();
	}

	
	public Booking updateBooking(Booking booking, int bookingId) throws FlightManagementException{
		booking.setBookingId(bookingId);
		
		return bookingRepository.save(booking);
		
	}


	public void deleteBooking(int bookingId) {
		bookingRepository.deleteById(bookingId);
		
	}
		


	
}