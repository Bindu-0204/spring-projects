package com.cg.flight.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flight.model.Booking;
import com.cg.flight.repository.BookingRepository;




@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	BookingRepository bookingRepository;

public Booking addBooking(Booking booking) {
		
		return bookingRepository.save(booking);
	}

	
	public Booking getBookingById(int bookingId) {
		
		
		return bookingRepository.getOne(bookingId); //findOne(id);
	}

	
	public List<Booking> getBooking() {
		
		return bookingRepository.findAll();
	}

	
	public Booking updateBooking(Booking booking, int bookingId) {
		
		return bookingRepository.save(booking);
		
	}
		


	
}