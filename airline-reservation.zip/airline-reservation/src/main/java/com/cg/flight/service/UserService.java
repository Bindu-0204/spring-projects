package com.cg.flight.service;




import java.util.List;

import com.cg.flight.model.User;


public interface UserService {
	public User addUser(User user);
	public User getUserById(int userId);

	public void updateUser(User user, int userId);
	public List<User> getAllUser();

    
    
}
