package com.cg.flight.service;

import java.util.List;

import com.cg.flight.exception.FlightManagementException;
import com.cg.flight.model.User;


public interface UserService {
	public User addUser(User user) throws FlightManagementException;
	public User getUser(int userId) throws FlightManagementException;
	public List<User> getAllUser() throws FlightManagementException;
	public void updateUser(User user, int userId) throws FlightManagementException;
	public void deleteUser(int userId) throws FlightManagementException;
    
}
