package com.cg.flight.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
@SequenceGenerator(name = "seq", initialValue = 1, allocationSize = 100)
public class Flight {

	@Column(name = "FlightNo")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int flightNo;

	@Column(name = "Airline")
	private String airline;

	@Column(name = "DepCity")
	private String depCity;

	@Column(name = "ArrCity")
	private String arrCity;

	@Column(name = "DepDate")
	private Date depDate;

	@Column(name = "ArrDate")
	private Date arrDate;

	@Column(name = "DepTime")
	private Date depTime;

	@Column(name = "ArrTime")
	private Date arrTime;

	@Column(name = "FirstSeats")
	private int firstSeats;

	@Column(name = "FirstSeatsFare")
	private double firstSeatsFare;

	@Column(name = "BussSeats")
	private int bussSeats;

	@Column(name = "BussSeatsFare")
	private double bussSeatsFare;

	@ManyToOne
	@JoinColumn(name = "flight", insertable = false, updatable = false)
	private Airport airport;

	@OneToMany(mappedBy = "flight")
	private List<Booking> booking;

	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDepCity() {
		return depCity;
	}

	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}

	public String getArrCity() {
		return arrCity;
	}

	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}

	public Date getDepDate() {
		return depDate;
	}

	public void setDepDate(Date depDate) {
		this.depDate = depDate;
	}

	public Date getArrDate() {
		return arrDate;
	}

	public void setArrDate(Date arrDate) {
		this.arrDate = arrDate;
	}

	public Date getDepTime() {
		return depTime;
	}

	public void setDepTime(Date depTime) {
		this.depTime = depTime;
	}

	public Date getArrTime() {
		return arrTime;
	}

	public void setArrTime(Date arrTime) {
		this.arrTime = arrTime;
	}

	public int getFirstSeats() {
		return firstSeats;
	}

	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}

	public double getFirstSeatsFare() {
		return firstSeatsFare;
	}

	public void setFirstSeatsFare(double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}

	public int getBussSeats() {
		return bussSeats;
	}

	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}

	public double getBussSeatsFare() {
		return bussSeatsFare;
	}

	public void setBussSeatsFare(double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}

	public Airport getAirport() {
		return airport;
	}

	public void setAirport(Airport airport) {
		this.airport = airport;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}

	public Flight(int flightNo, String airline, String depCity, String arrCity, Date depDate, Date arrDate,
			Date depTime, Date arrTime, int firstSeats, double firstSeatsFare, int bussSeats, double bussSeatsFare,
			Airport airport, List<Booking> booking) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.depCity = depCity;
		this.arrCity = arrCity;
		this.depDate = depDate;
		this.arrDate = arrDate;
		this.depTime = depTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.bussSeats = bussSeats;
		this.bussSeatsFare = bussSeatsFare;
		this.airport = airport;
		this.booking = booking;
	}

}
