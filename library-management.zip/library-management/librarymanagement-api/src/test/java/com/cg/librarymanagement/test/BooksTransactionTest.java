package com.cg.librarymanagement.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.cg.librarymanagement.entities.BooksInventory;
import com.cg.librarymanagement.entities.BooksRegistration;
import com.cg.librarymanagement.entities.BooksTransaction;
import com.cg.librarymanagement.repository.BooksInventoryRepo;
import com.cg.librarymanagement.repository.BooksRegistrationRepo;
import com.cg.librarymanagement.repository.BooksTransactionRepo;
import com.cg.librarymanagement.repository.UsersRepo;
import com.cg.librarymanagement.service.BooksTransactionServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class BooksTransactionTest {

	@Mock
	BooksTransactionRepo transactionRepo;
	@Mock
	BooksRegistrationRepo registrationRepo;
	@Mock
	BooksInventoryRepo inventoryRepo;
	@Mock
	UsersRepo usersRepo;
	
	@InjectMocks
	private BooksTransactionServiceImpl transactionService;
	
	@Test
	public void updateTransaction()
	{
		BooksTransaction trans1 = new BooksTransaction();
		trans1.setTransactionId(104);
		trans1.setRegistrationId(103);
		trans1.setIssueDate(LocalDate.of(2019,04,11));
		trans1.setReturnDate(LocalDate.of(2019,04,24));
		trans1.setFine(3);
		
		BooksRegistration bookRegistration= new BooksRegistration();
		bookRegistration.setRegistrationId(103);
		bookRegistration.setBookId(102);
		bookRegistration.setUserId(101);
		
		BooksInventory bookInventory = new BooksInventory();
		bookInventory.setBookId(102);
		bookInventory.setAuthor1("Mr. John");
		bookInventory.setBookName("REST");
		bookInventory.setGenre("Technical");
		bookInventory.setPublisher("techno ltd");
		bookInventory.setYearOfPublication("2017");
		
		
		Optional<BooksTransaction> booksTransOptional= Optional.of(trans1);
		
		Optional<BooksRegistration> booksRegOptional= Optional.of(bookRegistration);
	
		when(transactionRepo.findById(104)).thenReturn(booksTransOptional);
		
		when(registrationRepo.findById(103)).thenReturn(booksRegOptional);
		
		
		when(transactionRepo.save(anyOb)).thenReturn(trans1);
		BooksTransaction trans2 = transactionService.updateTransaction(trans1);
		
		assertEquals(trans2, trans1);
	}
	
	
}
