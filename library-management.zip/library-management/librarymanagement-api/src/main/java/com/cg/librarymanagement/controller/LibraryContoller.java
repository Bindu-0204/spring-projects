package com.cg.librarymanagement.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.librarymanagement.entities.BooksInventory;
import com.cg.librarymanagement.entities.BooksRegistration;
import com.cg.librarymanagement.entities.BooksTransaction;
import com.cg.librarymanagement.entities.Users;
import com.cg.librarymanagement.exception.LibraryManagementException;
import com.cg.librarymanagement.service.BooksInventoryServiceImpl;
import com.cg.librarymanagement.service.BooksRegistrationServiceImpl;
import com.cg.librarymanagement.service.BooksTransactionServiceImpl;
import com.cg.librarymanagement.service.UsersServiceImpl;

@RestController
public class LibraryContoller {
	
	@Autowired
	BooksInventoryServiceImpl bookService;
	@Autowired
	BooksRegistrationServiceImpl registartionService;
	@Autowired
	BooksTransactionServiceImpl transactionService;
	@Autowired
	UsersServiceImpl userService;
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
			MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	}  
	
	//............................... add book .....................................
	@RequestMapping(value = "/book",method = RequestMethod.POST)
	public BooksInventory addBook(@RequestBody BooksInventory book)
	{
		return bookService.addBook(book);
	}
	
	//............................... update book .....................................
	@RequestMapping(value = "/book",method = RequestMethod.PUT)
	public BooksInventory updateBook(@RequestBody BooksInventory book)
	{
		return bookService.updateBook(book);
		
	}
	
	//............................... delete book .....................................
	@RequestMapping(value = "/book/{id}",method = RequestMethod.DELETE)
	public BooksInventory deleteBook(@PathVariable int id)
	{
		return bookService.deleteBook(id);
	}
	
	//............................... find books.....................................
	@RequestMapping(value = "/book",method = RequestMethod.GET)
	public List<BooksInventory> getBooks()
	{
		return bookService.getBooks();
	}
	//............................... find book.....................................
	@RequestMapping(value = "/book/parameters", method = RequestMethod.GET)
	public List<BooksInventory> findByGenreAuthor(@RequestParam(value="genre") String genre,@RequestParam(value="author")String author)
	{
		return bookService.findByGenreAuthor(genre,author);
	}
	
	//............................... add request/registartion.....................................
	@RequestMapping(value = "/registration",method = RequestMethod.POST)
	public BooksRegistration addRegistration(@RequestBody @Valid BooksRegistration registration)
	{
		return registartionService.addRegistration(registration);
	}
	
	//............................... get request/registartion.....................................
	@RequestMapping(value = "/registration",method = RequestMethod.GET)
	public List<BooksRegistration> getRegistration()
	{
		return registartionService.getRegistration();
	}
	//............................... update request/registartion .....................................
	@RequestMapping(value = "/registration",method = RequestMethod.PUT)
	public BooksRegistration updtaeRequest(@RequestBody BooksRegistration registration)
	{
		return registartionService.updateRegistration(registration);
	}
		
	//............................... delete request/registartion .....................................
	@RequestMapping(value = "/registration/{id}",method = RequestMethod.DELETE)
	public BooksRegistration deleteRegistration(@PathVariable int id)
	{
		return registartionService.deleteRegistration(id);
	}
	
	//............................... add transaction.....................................
	@RequestMapping(value = "/transaction",method = RequestMethod.POST)
	public BooksTransaction addTransaction(@RequestBody BooksTransaction transaction)
	{
		return transactionService.addTransaction(transaction);
	}
	
	//............................... get transaction.....................................
	@RequestMapping(value = "/transaction",method = RequestMethod.GET)
	public List<BooksTransaction> getTransaction()
	{
		return transactionService.getTransaction();
	}
	//............................... update transaction .....................................
	@RequestMapping(value = "/transaction",method = RequestMethod.PUT)
	public BooksTransaction updateTransaction(@RequestBody BooksTransaction transaction)
	{
		transaction = transactionService.updateTransaction(transaction);
		return transaction;
	}
		
	//............................... delete transaction .....................................
	@RequestMapping(value = "/transaction/{id}",method = RequestMethod.DELETE)
	public BooksTransaction deleteTransaction(@PathVariable int id)
	{
		return transactionService.deleteTransaction(id);
	}
	
	//............................... add user.....................................
	@RequestMapping(value = "/users",method = RequestMethod.POST)
	public Users addUser(@RequestBody Users user)
	{
		return userService.addUser(user);
	}
	
	//............................... get user.....................................
	@RequestMapping(value = "/users",method = RequestMethod.GET)
	
	public List<Users> getUser()
	{
		return userService.getUser();
	}
	//............................... update user .....................................
		@RequestMapping(value = "/users",method = RequestMethod.PUT)
		public Users updateUser(@RequestBody Users user)
		{
			return userService.updateUser(user);
		}
	
	//...................... delete user .....................................
	@RequestMapping(value = "/users/{id}",method = RequestMethod.DELETE)
	public Users deleteUser(@PathVariable int id)
	{
		return userService.deleteUser(id);
	}
		
		
		
}
