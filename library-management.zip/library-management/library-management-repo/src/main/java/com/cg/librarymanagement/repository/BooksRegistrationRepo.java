package com.cg.librarymanagement.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.librarymanagement.entities.BooksRegistration;

public interface BooksRegistrationRepo extends JpaRepository<BooksRegistration, Integer>{

}
