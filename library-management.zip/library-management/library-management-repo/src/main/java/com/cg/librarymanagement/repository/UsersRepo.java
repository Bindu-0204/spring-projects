package com.cg.librarymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.librarymanagement.entities.Users;

public interface UsersRepo extends JpaRepository<Users, Integer>{

}
