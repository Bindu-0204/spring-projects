package com.cg.librarymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.librarymanagement.entities.BooksTransaction;

public interface BooksTransactionRepo extends JpaRepository<BooksTransaction, Integer>{

}
