package com.cg.librarymanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.librarymanagement.entities.BooksInventory;

@Repository
public interface BooksInventoryRepo extends JpaRepository<BooksInventory, Integer> {

	@Query("SELECT b from BooksInventory b WHERE b.genre like '%:genre%' OR b.author1 like '%:author%'")
	List<BooksInventory> findByGenreAuthor(@Param(value = "author") String autor, @Param(value = "genre") String genre);

}
