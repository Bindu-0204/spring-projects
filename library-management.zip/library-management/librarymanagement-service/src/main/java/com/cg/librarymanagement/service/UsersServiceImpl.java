package com.cg.librarymanagement.service;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.cg.librarymanagement.entities.BooksTransaction;
import com.cg.librarymanagement.entities.Users;
import com.cg.librarymanagement.exception.LibraryManagementException;
import com.cg.librarymanagement.repository.UsersRepo;
@Service
public class UsersServiceImpl implements UsersService {

	@Autowired
	UsersRepo usersRepo;

	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		return usersRepo.save(user);
	}

	@Override
	public List<Users> getUser() {
		// TODO Auto-generated method stub
		List<Users> list = usersRepo.findAll();
		if(list.size()==0)
			throw new LibraryManagementException(204,"No User/s found");
		return list;
	}
	
	@Override
	public Users updateUser(Users user) {
		// TODO Auto-generated method stub
		Optional<Users> existUser = usersRepo.findById(user.getUserId());
		if(existUser.isPresent()==false)
			throw new LibraryManagementException(204,"User with given ID not found");
		else
		{
			return usersRepo.save(user);
		}
	}

	@Override
	public Users deleteUser(int id) {
		// TODO Auto-generated method stub
		Optional<Users> existUser = usersRepo.findById(id);
		if(existUser.isPresent()==false)
			throw new LibraryManagementException(204,"User with ID: "+id+" not found");
		else
		{
			usersRepo.deleteById(id);
			return existUser.get();
		}
	}
}
