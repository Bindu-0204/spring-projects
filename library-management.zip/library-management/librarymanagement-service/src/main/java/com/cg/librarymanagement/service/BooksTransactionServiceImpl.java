package com.cg.librarymanagement.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import com.cg.librarymanagement.entities.BooksRegistration;
import com.cg.librarymanagement.entities.BooksTransaction;
import com.cg.librarymanagement.exception.LibraryManagementException;
import com.cg.librarymanagement.repository.BooksRegistrationRepo;
import com.cg.librarymanagement.repository.BooksTransactionRepo;

@Service
public class BooksTransactionServiceImpl implements BooksTransactionService {

	@Autowired
	BooksTransactionRepo transactioRepo;
	BooksRegistrationRepo registrationRepo;

	@Override
	public BooksTransaction addTransaction(BooksTransaction transaction) {
		// TODO Auto-generated method stub
		transaction.setIssueDate(LocalDate.now());
		transaction.setFine(0);
		BooksRegistration registration = registrationRepo.findById(transaction.getRegistrationId()).get();
		registration.setStatus("Issued");
		return transactioRepo.save(transaction);
	}

	@Override
	public BooksTransaction updateTransaction(BooksTransaction transaction) {
		// TODO Auto-generated method stub
		Optional<BooksTransaction> existRequest = transactioRepo.findById(transaction.getTransactionId());
		if(!existRequest.isPresent())
			throw new LibraryManagementException(204,"Transaction with given ID not available");
		else
		{
			BooksRegistration registration = registrationRepo.findById(transaction.getRegistrationId()).get();
			registration.setStatus("Returned");
			transaction=existRequest.get();
			transaction.setReturnDate(LocalDate.now());
			int days = (int) ChronoUnit.DAYS.between(transaction.getIssueDate(),transaction.getReturnDate());
			if(days>10)
				transaction.setFine(days-10);
			return transactioRepo.save(transaction);
		}
	}

	@Override
	public BooksTransaction deleteTransaction(int id) {
		// TODO Auto-generated method stub
		Optional<BooksTransaction> existTransactiont = transactioRepo.findById(id);
		if(!existTransactiont.isPresent())
			throw new LibraryManagementException(204,"Transaction with given ID not available");
		else
		{
			transactioRepo.deleteById(id);
			return existTransactiont.get();
		}
	}

	@Override
	public List<BooksTransaction> getTransaction() {
		// TODO Auto-generated method stub
		List<BooksTransaction> list = transactioRepo.findAll();
		if(list.size()==0)
			throw new LibraryManagementException(204,"No Transactions present");
		return list;
	}
}
