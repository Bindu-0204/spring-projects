package com.cg.librarymanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RequestParam;

import com.cg.librarymanagement.entities.BooksInventory;

public interface BooksInventoryService {
	public BooksInventory addBook(BooksInventory book);
	public BooksInventory deleteBook(int id);
	public BooksInventory updateBook(BooksInventory book);
	public List<BooksInventory> getBooks();
	public List<BooksInventory> findByGenreAuthor(String genre,String author);
}
