package com.cg.librarymanagement.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.librarymanagement.entities.BooksTransaction;

public interface BooksTransactionService{
	public BooksTransaction addTransaction(@RequestBody BooksTransaction transaction);
	public BooksTransaction updateTransaction(@RequestBody BooksTransaction transaction);
	public BooksTransaction deleteTransaction(@PathVariable int id);
	public List<BooksTransaction> getTransaction();
		
}
