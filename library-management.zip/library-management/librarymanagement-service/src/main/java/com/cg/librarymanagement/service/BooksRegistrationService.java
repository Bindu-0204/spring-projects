package com.cg.librarymanagement.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.cg.librarymanagement.entities.BooksInventory;
import com.cg.librarymanagement.entities.BooksRegistration;

public interface BooksRegistrationService {
	
	public BooksRegistration addRegistration(BooksRegistration registration);
	public BooksRegistration updateRegistration(@RequestBody BooksRegistration registration);
	public BooksRegistration deleteRegistration(int id);
	public List<BooksRegistration> getRegistration();
}
