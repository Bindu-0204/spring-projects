package com.cg.librarymanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.librarymanagement.entities.BooksInventory;
import com.cg.librarymanagement.exception.LibraryManagementException;
import com.cg.librarymanagement.repository.BooksInventoryRepo;

@Service
public class BooksInventoryServiceImpl implements BooksInventoryService {

	@Autowired
	BooksInventoryRepo inventoryRepo;
	
	@Override
	public BooksInventory addBook(BooksInventory book) {
		// TODO Auto-generated method stub
		return inventoryRepo.save(book);

	}

	@Override
	public BooksInventory deleteBook(int id) {
		// TODO Auto-generated method stub
		Optional<BooksInventory> existBook = inventoryRepo.findById(id);
		if(existBook.isPresent()==false)
			throw new LibraryManagementException(204,"Book not found");
		else
		{
			inventoryRepo.deleteById(id);
			return existBook.get();
		}
	}

	
	public BooksInventory updateBook(BooksInventory book) {
		// TODO Auto-generated method stub
		Optional<BooksInventory> existBook = inventoryRepo.findById(book.getBookId());
		if(!existBook.isPresent())
			throw new LibraryManagementException(204,"Book with given ID not found");
		else
			return inventoryRepo.save(book);
		
	}

	@Override
	public List<BooksInventory> getBooks() {
		// TODO Auto-generated method stub
		List<BooksInventory> books = inventoryRepo.findAll();
		if(books.size()==0)
			throw new LibraryManagementException(204,"No Books found");
		return books;
	}

	@Override
	public List<BooksInventory> findByGenreAuthor(String genre, String author) {
		// TODO Auto-generated method stub
		List<BooksInventory> books =  inventoryRepo.findByGenreAuthor(genre, author);
		if(books.size()==0)
			throw new LibraryManagementException(204,"No Books found");
		return books;
	}

	
}
