package com.cg.librarymanagement.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.librarymanagement.entities.Users;

public interface UsersService {
	public Users addUser(@RequestBody Users user);
	public Users updateUser(@RequestBody Users user);	
	public Users deleteUser(@PathVariable int id);
	public List<Users> getUser();
}
