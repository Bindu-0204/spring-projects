package com.cg.librarymanagement.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.librarymanagement.entities.BooksInventory;
import com.cg.librarymanagement.entities.BooksRegistration;
import com.cg.librarymanagement.exception.LibraryManagementException;
import com.cg.librarymanagement.repository.BooksRegistrationRepo;
@Service
public class BooksRegistrationServiceImpl implements BooksRegistrationService {

	@Autowired
	BooksRegistrationRepo registrationRepo;

	
	@Override
	public BooksRegistration addRegistration(BooksRegistration registration) {
		// TODO Auto-generated method stub
		
		registration.setRegistrationdate(LocalDate.now());
		registration.setStatus("Requested");
		
		return registrationRepo.save(registration);
	}


	@Override
	public BooksRegistration updateRegistration(BooksRegistration registration) {
		// TODO Auto-generated method stub
		Optional<BooksRegistration> existRequest = registrationRepo.findById(registration.getRegistrationId());
		if(existRequest.isPresent()==false)
			throw new LibraryManagementException(204,"Request with given ID not found");
		else
			return registrationRepo.save(registration);
	}


	@Override
	public BooksRegistration deleteRegistration(int id) {
		// TODO Auto-generated method stub
		Optional<BooksRegistration> existRequest = registrationRepo.findById(id);
		if(existRequest.isPresent()==false)
			throw new LibraryManagementException(204,"Request with ID: "+id+" not found");
		else
		{
			registrationRepo.deleteById(id);
			return existRequest.get();
		}
	}


	@Override
	public List<BooksRegistration> getRegistration() {
		// TODO Auto-generated method stub
		List<BooksRegistration> list =  registrationRepo.findAll();
		if(list.size()==0)
			throw new LibraryManagementException(204,"No request/s found");
		return list;
	}


	
}
