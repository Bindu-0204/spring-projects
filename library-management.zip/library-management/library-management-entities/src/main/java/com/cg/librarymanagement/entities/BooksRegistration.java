package com.cg.librarymanagement.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder.Default;
import lombok.Data;

@Entity
@Data
@JsonIgnoreProperties({ "handler", "hibernateLazyInitializer" })
//@Table(name = "BOOKS_REGISTRATION")
@SequenceGenerator(name = "registration_seq", initialValue = 101, allocationSize = 1)
public class BooksRegistration implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "registration_seq")
//	 @Column(name="REGISTRATION_ID")
	int registrationId;
	
	@NotNull(message = "Book ID is expected to process the request")
	int bookId;
	
	@NotNull(message = "User ID is expected to process the request")
	int userId;
	//@DateTimeFormat(pattern ="dd-MMM-yy") 
	LocalDate registrationdate;
	@Value("${:Requested}")
	String status; //RegistrationStatus: Requested, Issued, Returned and Closed
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "bookId", insertable = false, updatable = false)
	private BooksInventory book;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "userId", insertable = false, updatable = false)
	private Users user;
}
