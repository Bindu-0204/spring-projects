package com.cg.librarymanagement.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
//@Table(name = "BOOKS_TRANSACTION")
@SequenceGenerator(name = "transaction_seq", initialValue = 101, allocationSize = 1)
public class BooksTransaction implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_seq")
	private int transactionId;
	@NotNull(message = "registrationId is expected to handle the request")
	private int registrationId;
	
	private LocalDate issueDate;
	
	private LocalDate returnDate;
//	@Value("${:0}")
	private int fine;
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "registrationId", insertable = false, updatable = false)
	private BooksRegistration registration;

}
