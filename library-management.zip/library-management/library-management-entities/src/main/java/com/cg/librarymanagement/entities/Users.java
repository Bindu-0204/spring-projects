package com.cg.librarymanagement.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Entity
@Data
//@Table(name = "USERS")
@SequenceGenerator(name="user_seq", initialValue=101, allocationSize=1)
public class Users implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="user_seq")
	@Column(name = "UID", updatable = false, nullable = false)
	private int userId;
	@NotNull(message = "User name is expected to process the request")
	@Column(name = "UNAME")
	private String userName;
	@NotNull(message = "Password is expected to process the request")
	@Column(name = "UPASS")
	private String password;
	@NotNull(message = "Email is expected to process the request")
	@Column(name = "UEMAIL")
	@Email
	private String emailId;
	@NotNull(message = "Role is expected to process the request")
	@Column(name = "UROLE")
	private String role; 
	
}
