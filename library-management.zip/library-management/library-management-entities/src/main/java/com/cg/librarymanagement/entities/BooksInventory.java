package com.cg.librarymanagement.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
//@Table(name = "BOOKS_INVENTORY")
@SequenceGenerator(name="inventory_seq", initialValue=101, allocationSize=1)
public class BooksInventory implements Serializable 
{
	@Id 
	@NotNull 
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="inventory_seq")
	//@Column(name="BOOK_ID")
	private int bookId;
	
	//@Column(name="NAME")
	@NotNull(message = "Book Name is expected to process the request")
	private String bookName;
	
	//@Column(name="AUTHOR1")
	@NotNull(message = "Atleast one author name is expected to process the request")
	private String author1;
	
	//@Column(name="AUTHOR2")
	private String author2;
	
	//@Column(name="GENRE")
	@NotNull(message = "Genre is expected to process the request")
	private String genre;
	
	//@Column(name="PUBLISHER")
	@NotNull(message = "Publisher is expected to process the request")
	private String publisher;
	
	//@Column(name="YEAR_PUBLISHED")
	@NotNull(message = "Year of publication is expected to process the request")
	private String yearOfPublication; 
}
