//package com.cg.librarymanagement.log;
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.AfterReturning;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.Configuration;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Configuration
//@Aspect
//public class LoggingAspect {
//private Logger log = LoggerFactory.getLogger(this.getClass());
//private ObjectMapper mapper = new ObjectMapper();
//
//@Before("execution(* com.cg.librarymanagement.service.BooksInventoryServiceImpl.*(..))")
//public void enteringService(JoinPoint joinpoint)
//{
//	log.info("Entered into "+joinpoint.getStaticPart().getSignature().getName());
//	try {
//		log.info("Input parameters : "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(joinpoint.getArgs()));
//	} catch (JsonProcessingException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//}
//
//@AfterReturning("execution(* com.cg.librarymanagement.BooksInventoryServiceImpl.*(..))")
//public void exitingService(JoinPoint joinpoint,Object result)
//{
//	log.info("Exiting "+joinpoint.getStaticPart().getSignature().getName());
//	try {
//		log.info("Output parameters : "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(result!=null?result:""));
//	} catch (JsonProcessingException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//}
//}
