package com.cg.librarymanagement.exception;

public class LibraryManagementException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	
	private int code;
	private String message;
		
	public LibraryManagementException(int code, String msg) {
		super();
		this.code = code;
		this.message = msg;
		
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "LibraryManagementException [code=" + code + ", msg=" + message + "]";
	}
	
	

}
