package com.cg.student.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
public class Student {
	@Id
	@NotNull
	private int studId;

	@Size(min = 4, message = "Length between 4-8 characters")
	private String studname;

	@Size(min = 1, message = "Length between 1-6 characters")
	private String studgender;

	// @Min(21)
	private int studage;

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getStudname() {
		return studname;
	}

	public void setStudname(String studname) {
		this.studname = studname;
	}

	public String getStudgender() {
		return studgender;
	}

	public void setStudgender(String studgender) {
		this.studgender = studgender;
	}

	public int getStudage() {
		return studage;
	}

	public void setStudage(int studage) {
		this.studage = studage;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studname=" + studname + ", studgender=" + studgender + ", studage="
				+ studage + "]";
	}

}
