package com.cg.student.service;

import java.util.List;

import com.cg.student.entities.Student;
import com.cg.student.exception.StudentExceptionHandler;
import com.cg.student.exception.StudentManagementException;


public interface IStudentService {
	public	Student addStudent(Student student) throws StudentManagementException;

	 public	Student getStudentDetails(int id);

	 public	List<Student> getStudents();

	 public	Student updateStudent(Student student, int id);

	}


