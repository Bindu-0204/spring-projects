package com.cg.student.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.student.entities.Student;
import com.cg.student.repositories.StudentRepository;



@Service
public class StudentService  implements IStudentService{

	@Autowired
	StudentRepository studentRepository;
	
	Logger log = LoggerFactory.getLogger(this.getClass());

	public Student addStudent(Student student) {
		
		return studentRepository.save(student);
	}

	
	public Student getStudentDetails(int id) {
		
		log.info("In service- get StudentDetails");
		return studentRepository.getOne(id); //findOne(id);
	}

	
	public List<Student> getStudents() {
		
		return studentRepository.findAll();
	}

	
	public Student updateStudent(Student student, int id) {
		
		return studentRepository.save(student);
		
	}
		

}
