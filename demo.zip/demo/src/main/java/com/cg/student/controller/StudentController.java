package com.cg.student.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.student.entities.Student;
import com.cg.student.exception.StudentManagementException;
import com.cg.student.service.IStudentService;


@RestController
public class StudentController {
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	IStudentService studentService;
	
	@RequestMapping(value="/student", method=RequestMethod.POST)
	public Student addStudent(@RequestBody Student student) {

		log.info(student.toString());
		
		return studentService.addStudent(student);

	}

	@RequestMapping(value="/student/{id}", method=RequestMethod.GET)
	public Student getStudentDetails(@PathVariable int id) throws StudentManagementException {
 
		Student student = studentService.getStudentDetails(id);
		if(student==null)
		 throw new StudentManagementException(205,"Student Not Found");
		return student;

	}

	@RequestMapping(value="/student", method=RequestMethod.GET)
	public List<Student> getStudents() {

		return studentService.getStudents();

	}

	@RequestMapping(value="/student/{id}", method=RequestMethod.PUT)
	public void updateStudent(@RequestBody Student student, @PathVariable int id) {

		studentService.updateStudent(student,id);
	}

	

}
