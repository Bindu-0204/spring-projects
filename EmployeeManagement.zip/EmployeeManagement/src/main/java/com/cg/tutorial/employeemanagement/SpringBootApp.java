package com.cg.tutorial.employeemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@EnableAutoConfiguration
public class SpringBootApp {
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootApp.class, args);

	}

}
/*	String cronofyCode;

@RequestMapping(value = "/registration", method = RequestMethod.GET)
public String registration(Model model) {

	model.addAttribute("userForm", new User());

	return "registration";
}


@RequestMapping(value = { "adminPage" }, method = RequestMethod.GET)
public String adminPage(Model model) {
	model.addAttribute("airportForm", new Airport());
	return "adminPage";
}


@RequestMapping(value = { "userPage" }, method = RequestMethod.GET)
public String userPage(Model model) {
	model.addAttribute("airportForm", new Airport());
	return "userPage";
}


@RequestMapping(value = "/adminPage/addAirportPage")
public String addAirportPage(Model model) {
	model.addAttribute("airportForm", new Airport());

	return "addAirport";
}



@RequestMapping(value = "/registration", method = RequestMethod.POST)
public String registration(@Valid @ModelAttribute("userForm") User userForm, BindingResult bindingResult,
		Model model) throws TicketCounterException {

	if (userService.findByUsername(userForm.getUsername()) != null) {
		model.addAttribute("errorMessage", "UserName exists");
		return "registration";
	}

	if (bindingResult.hasErrors()) {
		return "registration";
	}

	userForm.setRole("USER");
	userService.save(userForm);
	securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

	return "redirect:/userPage";
}




@RequestMapping(value = "/adminPage/addAirport", method = RequestMethod.POST)
public String addMovie(@Valid @ModelAttribute("airportForm") Airport airportForm, BindingResult bindingResult,
		Model model) throws TicketCounterException {

	if (bindingResult.hasErrors()) {
		return "addAirport";
	}

	airportService.save(airportForm);

	model.addAttribute("airportForm", airportForm);

	return "redirect:/adminPage";
}

@RequestMapping(value = "/login", method = RequestMethod.GET)
public String login(Model model, String error, String logout) throws Exception {

	if (count == 0) {

		String input = "02/12/2018";
		/*
		 * DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		 * LocalDate date = LocalDate.parse(input, formatter); System.out.printf("%s%n",
		 * date);
		 */

/*		userService.save(
				new User("bindu", "hellohello", "USER", 9032849214));
		userService.save(new User( "admin", "hellohello", "ADMIN", 7896541230));
		movieService.save(new Movie((long) 15689, "Hello", 5, 300));
		Shows show = new Shows(input, 4, 300, "06:00 PM-09:00 PM", movieService.findByName((long) 1));
		showsService.setShows(show);

		movieService.save(new Movie((long) 15489, "MCA", 6, 350));
		show = new Shows(input, 5, 600, "11:00 AM-02:00 PM", movieService.findByName((long) 2));
		showsService.setShows(show);

		movieService.save(new Movie((long) 15589, "Velaikkaran", 3, 500));
		show = new Shows(input, 6, 521, "03:00PM -05:00PM", movieService.findByName((long) 3));
		show = showsService.setShows(show);

		count++;
	}

	if (error != null)
		model.addAttribute("error", "Your username and password is invalid.");

	if (logout != null)
		model.addAttribute("message", "You have been logged out successfully.");

	return "login";
}

// @PreAuthorize("hasRole('ADMIN')")
// @Secured(value = "ADMIN")
@RequestMapping(value = { "/adminPage/movieListPage" }, method = RequestMethod.GET)
public String movieListPage(Model model) throws TicketCounterException {

	List<Movie> movies = new ArrayList<Movie>();

	movies = movieService.getAllMovies();

	if (movies.isEmpty()) {
		model.addAttribute("listNull", false);
	} else {
		model.addAttribute("listNull", true);
	}
	model.addAttribute("movies", movies);
	return "movieList";
}

// @PreAuthorize("hasRole('USER')")
@RequestMapping(value = { "userPage/bookTicketPage" }, method = RequestMethod.GET)
public String bookTicketPage(Model model) throws TicketCounterException {
	List<Movie> movies = null;

	movies = movieService.getAllMovies();

	if (movies.isEmpty()) {
		model.addAttribute("listNull", false);
	} else {
		model.addAttribute("listNull", true);
	}
	model.addAttribute("movies", movies);
	return "bookTicket";
}
*/
}
